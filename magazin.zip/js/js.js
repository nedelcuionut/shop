function myFunction() {
    alert("Produsul a fost adaugat in cos!");
}




